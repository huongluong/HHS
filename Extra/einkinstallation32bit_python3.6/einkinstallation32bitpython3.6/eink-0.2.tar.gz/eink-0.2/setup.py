"""
setup.py file for installing eink python wrapper
"""

from setuptools import setup
from distutils.sysconfig import get_python_lib

# run setup
setup(
    name='eink',
    # change this when wrapper version changes
    version='0.2',
    description='eink wrapper',
    data_files=[
        ('Lib\site-packages', [
            '_eink.pyd',
        ]),
    ],
    py_modules=['eink'],
)