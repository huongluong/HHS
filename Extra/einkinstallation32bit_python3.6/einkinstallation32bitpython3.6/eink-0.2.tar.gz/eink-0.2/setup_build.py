"""
setup_build.py file for building the eink python wrapper
"""

from setuptools import setup, Extension
from distutils.command.build import build
from setuptools.command.install import install

class CustomBuild(build):
    def run(self):
        self.run_command('build_ext')
        build.run(self)


class CustomInstall(install):
    def run(self):
        self.run_command('build_ext')
        install.run(self)


eink_module = Extension(
    '_eink',
    library_dirs=['C:\Program Files (x86)\Datalogic\eink'],
    libraries=['EInk'],
    sources=[
        'eink.i',
    ],
)

setup(
    cmdclass={'build': CustomBuild, 'install': CustomInstall},
    name = 'eink',
    version = '0.1',
    author = 'Datalogic',
    description = 'eink wrapper',
    ext_modules = [eink_module],
    py_modules = ['eink'],
)