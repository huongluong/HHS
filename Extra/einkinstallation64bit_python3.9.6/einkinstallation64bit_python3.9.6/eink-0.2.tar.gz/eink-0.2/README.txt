Process to build eink.tar.gz
1. Edit install_template.bat to match the version of Python being run 
(see install.bat for example for Python 2.7).
2. Find eink_<version>.tar.gz in dist folder.
3. Copy to einkinstallation64bit to complete installation.